@file:OptIn(ExperimentalMaterial3Api::class)

package com.blendora.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

@Composable
private fun FilterTile(
    label: String, value: Int, color: Color, icon: ImageVector, selected: Boolean, modifier: Modifier, onClick: () -> Unit
) {
    val fg = readable(color)
    Column(
        modifier.clip(RoundedCornerShape(Rd.m)).background(color.copy(alpha = if (selected) 0.18f else 0.07f))
            .border(if (selected) 2.dp else 1.dp, color.copy(alpha = if (selected) 1f else 0.25f), RoundedCornerShape(Rd.m))
            .clickable { onClick() }.heightIn(min = 48.dp).padding(vertical = Sp.m),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Icon(icon, null, tint = fg, modifier = Modifier.size(18.dp))
        Text("$value", style = MaterialTheme.typography.headlineSmall, color = fg)
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun ResultRow(e: Entry, listId: String) {
    val canStage = St.isAnswered(e.status)
    Panel(Modifier.fillMaxWidth(), onClick = if (canStage) ({ Store.stageTarget = listId to e.id }) else null) {
        Column(Modifier.padding(Sp.m), verticalArrangement = Arrangement.spacedBy(Sp.s)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(e.name.ifBlank { e.number }, if (e.stage != Stg.NONE) Stg.color(e.stage) else statusColor(e.status))
                Spacer(Modifier.width(Sp.m))
                Column(Modifier.weight(1f)) {
                    Text(e.name.ifBlank { e.number }, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (e.name.isNotBlank()) NumText(e.number, style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (e.stage != Stg.NONE) WhatsAppButton(e.number)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.horizontalScroll(rememberScrollState())) {
                StatusPill(e.status)
                if (e.calledAt > 0) Pill(fmtTime(e.calledAt), MaterialTheme.colorScheme.onSurfaceVariant, Icons.Rounded.History)
                if (e.duration > 0) Pill(fmtDur(e.duration), Sem.success, Icons.Rounded.Schedule)
                if (e.stage != Stg.NONE) StagePill(e.stage) { Store.stageTarget = listId to e.id }
                else if (St.isAnswered(e.status)) Pill(T("+ Stage", "+ نتيجة"), MaterialTheme.colorScheme.primary) {
                    Store.stageTarget = listId to e.id
                }
            }
            if (e.feedback.isNotBlank()) {
                Text(e.feedback, style = MaterialTheme.typography.bodySmall.copy(fontStyle = FontStyle.Italic),
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun ResultsScreen() {
    val ctx = LocalContext.current
    val sel = Store.resultsListId?.takeIf { id -> Store.lists.any { it.id == id } }
        ?: Store.runListId?.takeIf { id -> Store.lists.any { it.id == id } }
        ?: Store.lists.firstOrNull()?.id
    val list = Store.lists.find { it.id == sel }
    var f by remember { mutableIntStateOf(0) }

    Scaffold(
        topBar = {
            BlendBar(T("Results", "النتائج"), subtitle = list?.name, actions = {
                if (list != null) IconButton(onClick = { shareText(ctx, Store.listReport(list)) }) {
                    Icon(Icons.Rounded.Share, T("Share report", "مشاركة التقرير"))
                }
            })
        },
        containerColor = Color.Transparent
    ) { pad ->
        if (list == null) {
            EmptyState(Icons.Rounded.BarChart, T("No results yet", "لا توجد نتائج بعد"),
                T("Run a campaign and its results will appear here.", "شغّل حملة وستظهر نتائجها هنا."), Modifier.padding(pad),
                actionText = T("Go to campaigns", "الذهاب إلى الحملات"), onAction = { Store.tab = 0 })
        } else {
            val p = Store.prog(list)
            val rows = list.entries.filter {
                when {
                    f == 0 -> it.status != St.PENDING && it.status != St.CALLING
                    f == 1 -> St.isAnswered(it.status)
                    f == 2 -> it.status == St.NO_ANSWER
                    f == 3 -> it.status == St.FAILED
                    f >= 10 -> it.stage == f - 10
                    else -> true
                }
            }.sortedByDescending { it.calledAt }
            val staged = list.entries.count { it.stage != Stg.NONE }
            val filterName = when {
                f == 0 -> T("All called numbers", "كل الأرقام المتصل بها")
                f == 1 -> T("Answered", "ردّوا")
                f == 2 -> T("No answer", "لم يردّوا")
                f == 3 -> T("Failed", "فشل")
                else -> Stg.label(f - 10)
            }
            LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(Sp.xl, Sp.s, Sp.xl, 100.dp),
                verticalArrangement = Arrangement.spacedBy(Sp.l)) {

                if (Store.lists.size > 1) item {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
                        Store.lists.forEach { l ->
                            FilterChip(selected = l.id == list.id, onClick = { Store.resultsListId = l.id; f = 0 },
                                label = { Text(l.name, maxLines = 1) })
                        }
                    }
                }

                if (p.total > 0 && p.remaining == 0) item {
                    Banner(Tk.SUCCESS, T("Campaign completed", "اكتملت الحملة"),
                        T("${p.answered} of ${p.total} answered", "${p.answered} من ${p.total} ردّوا"))
                }

                item {
                    Panel(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(Sp.l), verticalArrangement = Arrangement.spacedBy(Sp.m)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(T("Overview", "نظرة عامة"), Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                                Text("${p.pct}%", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.titleMedium)
                            }
                            BProgress(p.pct / 100f)
                            Text(T("${p.called} of ${p.total} called · ${p.remaining} left", "${p.called} من ${p.total} · ${p.remaining} متبقي"),
                                style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Row(horizontalArrangement = Arrangement.spacedBy(Sp.s), modifier = Modifier.fillMaxWidth()) {
                                FilterTile(T("Answered", "ردّوا"), p.answered, Sem.success, Icons.Rounded.CheckCircle, f == 1, Modifier.weight(1f)) { f = 1 }
                                FilterTile(T("No answer", "لم يردّوا"), p.noAnswer, Sem.warning, Icons.Rounded.PhoneMissed, f == 2, Modifier.weight(1f)) { f = 2 }
                                FilterTile(T("Failed", "فشل"), p.failed, Sem.danger, Icons.Rounded.Error, f == 3, Modifier.weight(1f)) { f = 3 }
                            }
                        }
                    }
                }

                item {
                    Panel(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(Sp.l), verticalArrangement = Arrangement.spacedBy(Sp.m)) {
                            Text(T("Stage statistics", "إحصائيات المراحل"), style = MaterialTheme.typography.titleMedium)
                            Stg.all.forEach { s ->
                                val n = list.entries.count { it.stage == s }
                                val share = if (staged == 0) 0f else n / staged.toFloat()
                                Row(
                                    Modifier.fillMaxWidth().clip(RoundedCornerShape(Rd.s))
                                        .background(if (f == 10 + s) Stg.color(s).copy(alpha = 0.10f) else Color.Transparent)
                                        .clickable { f = 10 + s }.heightIn(min = 48.dp).padding(Sp.xs),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    IconTile(stageIcon(s), Stg.color(s), size = 38.dp)
                                    Spacer(Modifier.width(Sp.m))
                                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text(Stg.label(s), style = MaterialTheme.typography.titleSmall)
                                            Text("$n  ·  ${(share * 100).toInt()}%", color = readable(Stg.color(s)), style = MaterialTheme.typography.labelLarge)
                                        }
                                        BProgress(share, color = Stg.color(s), track = Stg.color(s).copy(alpha = 0.12f), height = 6.dp)
                                    }
                                }
                            }
                            val unstaged = p.answered - list.entries.count { St.isAnswered(it.status) && it.stage != Stg.NONE }
                            if (unstaged > 0) Text(T("$unstaged answered calls have no stage yet", "$unstaged مكالمة تم الرد عليها بدون نتيجة"),
                                style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }

                item {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(filterName + "  (${rows.size})", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                        if (f != 0) TextButton(onClick = { f = 0 }) { Text(T("Show all", "عرض الكل")) }
                    }
                }
                if (rows.isEmpty()) item {
                    Text(T("Nothing here yet.", "لا يوجد شيء هنا بعد."), color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                items(rows, key = { it.id }) { e -> ResultRow(e, list.id) }
            }
        }
    }
}

// ============================================================ call log
@Composable
fun LogScreen() {
    val ctx = LocalContext.current
    var f by remember { mutableIntStateOf(-1) }
    var confirm by remember { mutableStateOf(false) }
    val shown = Store.log.filter { f == -1 || it.status == f }
    Scaffold(
        topBar = {
            BlendBar(T("Call log", "سجل المكالمات"), actions = {
                IconButton(onClick = { if (shown.isNotEmpty()) shareText(ctx, Store.logReport(shown)) }) {
                    Icon(Icons.Rounded.Share, T("Share log", "مشاركة السجل"))
                }
                IconButton(onClick = { if (Store.log.isNotEmpty()) confirm = true }) {
                    Icon(Icons.Rounded.Delete, T("Clear log", "مسح السجل"))
                }
            })
        },
        containerColor = Color.Transparent
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = Sp.xl),
                horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
                listOf(-1 to T("All", "الكل"), St.ANSWERED to T("Answered", "ردّوا"), St.NO_ANSWER to T("No answer", "لم يردّوا"),
                    St.FAILED to T("Failed", "فشل"), St.DONE to T("Completed", "انتهت"))
                    .forEach { (k, n) -> FilterChip(selected = f == k, onClick = { f = k }, label = { Text(n) }) }
            }
            if (shown.isEmpty()) {
                EmptyState(Icons.Rounded.History, T("No calls logged", "لا يوجد سجل"),
                    T("Every call will be listed here.", "كل مكالمة هتظهر هنا."))
            } else {
                LazyColumn(contentPadding = PaddingValues(Sp.xl, Sp.m, Sp.xl, 100.dp), verticalArrangement = Arrangement.spacedBy(Sp.s)) {
                    items(shown) { l ->
                        Panel(Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(Sp.m), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text(l.name.ifBlank { l.number }, style = MaterialTheme.typography.titleSmall, maxLines = 1,
                                        overflow = TextOverflow.Ellipsis)
                                    if (l.name.isNotBlank()) NumText(l.number, style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(fmtTime(l.time) + " · " + l.listName + (if (l.duration > 0) " · ${fmtDur(l.duration)}" else "") +
                                        " · #${l.attempt}", style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                StatusPill(l.status)
                            }
                        }
                    }
                }
            }
        }
    }
    if (confirm) ConfirmDialog(T("Clear the whole call log?", "مسح كل السجل؟"), { confirm = false }) {
        Store.clearLog(); confirm = false; Store.notify(Tk.INFO, T("Call log cleared", "تم مسح السجل"))
    }
}
