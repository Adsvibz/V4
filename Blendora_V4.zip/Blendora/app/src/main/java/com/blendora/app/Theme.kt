package com.blendora.app

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat

/** Visible product name. Change it here to rebrand every screen. */
const val APP_NAME = "O2Dialer"
const val APP_VERSION = "3.2"

// ------------------------------------------------------------------ design tokens
/** Spacing scale (4-pt grid). */
object Sp {
    val xs = 4.dp
    val s = 8.dp
    val m = 12.dp
    val l = 16.dp
    val xl = 20.dp
    val xxl = 24.dp
    val xxxl = 32.dp
}

/** Corner radii. */
object Rd {
    val s = 12.dp
    val m = 16.dp
    val l = 20.dp
    val xl = 28.dp
}

/** Semantic colours: always use these for meaning, never ad-hoc colours. */
object Sem {
    val success = Color(0xFF16A34A)
    val warning = Color(0xFFF59E0B)
    val danger = Color(0xFFDC2626)
    val info = Color(0xFF2563EB)
}

/** Flat, solid surface for the live "hero" card. White text on it is 8:1 in both themes. */
val HeroBg = Color(0xFF3F2FC4)

/**
 * Text / icon colour that stays readable (>= 4.5:1) on a 10-20 % tint of [c],
 * in both the light and the dark theme. Use it instead of [c] itself for any text or icon.
 */
@Composable
fun readable(c: Color): Color {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    return if (dark) lerp(c, Color.White, 0.35f) else lerp(c, Color.Black, 0.38f)
}

private val Outfit = FontFamily(
    Font(R.font.outfit_regular, FontWeight.Normal),
    Font(R.font.outfit_bold, FontWeight.Bold)
)

private val PlexArabic = FontFamily(
    Font(R.font.plex_arabic_regular, FontWeight.Normal),
    Font(R.font.plex_arabic_bold, FontWeight.Bold)
)

private val LightC = lightColorScheme(
    primary = Color(0xFF5B3FE4), onPrimary = Color.White,
    primaryContainer = Color(0xFFECE8FF), onPrimaryContainer = Color(0xFF1B0B5C),
    secondary = Color(0xFF0EA5E9), background = Color(0xFFF6F6FA), surface = Color.White,
    surfaceVariant = Color(0xFFEFEFF6), onSurface = Color(0xFF14131A), onBackground = Color(0xFF14131A),
    onSurfaceVariant = Color(0xFF5F5F70), outline = Color(0xFFE2E2EB),
    inverseSurface = Color(0xFF1F1E26), inverseOnSurface = Color(0xFFF4F4F8)
)
private val DarkC = darkColorScheme(
    primary = Color(0xFFB9A9FF), onPrimary = Color(0xFF1B0B5C),
    primaryContainer = Color(0xFF3A2A8F), onPrimaryContainer = Color(0xFFECE8FF),
    secondary = Color(0xFF7DD3FC), background = Color(0xFF0B0B10), surface = Color(0xFF15151C),
    surfaceVariant = Color(0xFF1E1E27), onSurface = Color(0xFFF2F2F7), onBackground = Color(0xFFF2F2F7),
    onSurfaceVariant = Color(0xFFA3A3B5), outline = Color(0xFF2B2B37),
    inverseSurface = Color(0xFFEDEDF3), inverseOnSurface = Color(0xFF1B1B22)
)

fun statusColor(s: Int): Color = when (s) {
    St.ANSWERED -> Sem.success
    St.NO_ANSWER -> Sem.warning
    St.FAILED -> Sem.danger
    St.CALLING -> Sem.info
    St.DONE -> Color(0xFF0D9488)
    else -> Color(0xFF8A90A5)
}

private fun typo(ff: FontFamily, arabic: Boolean): Typography {
    // Arabic script needs more vertical room than Latin.
    val k = if (arabic) 1.12f else 1f
    fun st(w: FontWeight, size: Int, lh: Int) =
        TextStyle(fontFamily = ff, fontWeight = w, fontSize = size.sp, lineHeight = (lh * k).sp)
    val b = FontWeight.Bold
    val n = FontWeight.Normal
    return Typography(
        displayLarge = st(b, 40, 48), displayMedium = st(b, 34, 42), displaySmall = st(b, 30, 38),
        headlineLarge = st(b, 28, 36), headlineMedium = st(b, 24, 32), headlineSmall = st(b, 22, 28),
        titleLarge = st(b, 20, 26), titleMedium = st(b, 16, 22), titleSmall = st(b, 14, 20),
        bodyLarge = st(n, 16, 24), bodyMedium = st(n, 14, 20), bodySmall = st(n, 12, 16),
        labelLarge = st(b, 14, 20), labelMedium = st(n, 12, 16), labelSmall = st(n, 11, 14)
    )
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val c = Store.cfg
    val dark = when (c.themeMode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    val ctx = LocalContext.current
    val scheme = if (c.dynamicColor && Build.VERSION.SDK_INT >= 31) {
        if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
    } else if (dark) DarkC else LightC
    // IBM Plex Sans Arabic for Arabic mode, Outfit for English: one consistent voice per language.
    val arabic = c.lang == 1
    val ty = remember(c.lang) { typo(if (arabic) PlexArabic else Outfit, arabic) }
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val w = (view.context as? Activity)?.window
            if (w != null) {
                val ic = WindowCompat.getInsetsController(w, view)
                ic.isAppearanceLightStatusBars = !dark
                ic.isAppearanceLightNavigationBars = !dark
            }
        }
    }
    MaterialTheme(
        colorScheme = scheme, typography = ty,
        shapes = Shapes(
            extraSmall = RoundedCornerShape(14.dp), small = RoundedCornerShape(Rd.s), medium = RoundedCornerShape(Rd.m),
            large = RoundedCornerShape(Rd.l), extraLarge = RoundedCornerShape(Rd.xl)
        )
    ) {
        Surface(color = MaterialTheme.colorScheme.background, content = content)
    }
}
