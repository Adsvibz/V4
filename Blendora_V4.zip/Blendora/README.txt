O2Dialer v3.2 (package com.blendora.app)
Push this project to your GitHub repo root (keep .github/workflows/build.yml), run Actions, download the O2Dialer-APK artifact.
To rename the visible app name again: edit APP_NAME in Theme.kt and android:label in AndroidManifest.xml.
